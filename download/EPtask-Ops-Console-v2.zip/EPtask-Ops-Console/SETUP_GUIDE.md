# EPtask Ops Console — Laptop Setup Guide

This guide runs the complete application — the professional Next.js operations
console **and** the FastAPI simulation service that executes the original
EPtask V7.1 notebook code — on your own machine. No cloud services, no
accounts, no API keys from third parties. Everything runs locally.

---

## 1. What you are installing

```
┌────────────────────────────────────────────────────────────┐
│  Browser  (any modern Chrome / Edge / Firefox)             │
│    │                                                       │
│    ▼                                                       │
│  Frontend  ·  Next.js 16, port 3000                        │
│    Overview · Corridor 3D map · Compare networks ·         │
│    VEC cell · Outage study · Reference · About             │
│    │                                                       │
│    ▼  HTTP (direct, CORS enabled)                          │
│  Backend  ·  FastAPI + onnxruntime, port 8100              │
│    ├─ core/      the ORIGINAL eptask notebook modules      │
│    ├─ assets/    graph, ONNX models, reference results     │
│    └─ app/       services, jobs, auth, OSM integration     │
└────────────────────────────────────────────────────────────┘
```

Two processes, one folder. The frontend is a static build served by Node; the
backend is the scientist-facing Python service that runs the actual
simulations (corridor trials, VEC cell rollouts, outage studies) with the
notebook's own algorithms, parameters and model exports.

**v2 highlights**

- **Real OpenStreetMap roads** — one click fetches drivable highways for the
  corridor via the Overpass API (cached on disk) and rebuilds the road graph
  with the notebook's own `corridor.build_corridor()`. Offline or unusable
  extract → it falls back to the schematic and tells you why.
- **Compare networks** — edit a hazard preset (footprint, traffic, seed,
  dispatch) and run two warning-network modes side by side: two maps,
  informed-share curves, per-metric deltas — all computed live.
- **Persistent job history** — every run is stored in SQLite
  (`backend/data/jobs.db`) and survives restarts.
- **Optional API-key auth** — set `EPTASK_API_KEY` to lock the service; the
  console shows a key gate and sends `X-API-Key`.

---

## 2. Prerequisites

| Requirement | Minimum | Notes |
|---|---|---|
| Operating system | Windows 10/11, macOS 12+, Linux | anything that runs Python and Node |
| Python | 3.10 – 3.12 (3.12 recommended) | https://www.python.org/downloads/ — on Windows tick *Add python.exe to PATH* |
| Node.js | 20 LTS or newer | https://nodejs.org (npm comes with it). Bun 1.1+ also works, npm is assumed below |
| Disk | ~5 GB | PyTorch CPU wheel ≈ 900 MB unpacked; the app itself is small |
| RAM | 8 GB recommended | the OSM road graph build peaks around 2–3 GB |
| Internet | only for the first install and for live OSM fetching | the app itself runs fully offline |

---

## 3. Unpack and layout

Unzip the delivery, e.g. to `C:\EPtask` (Windows) or `~/eptask` (macOS/Linux).
You should see:

```
EPtask-Ops-Console/
├── README.md                 quick overview
├── SETUP_GUIDE.md            this file
├── .env.example              all configuration knobs, commented
├── docs/                     API.md · ARCHITECTURE.md · LIMITATIONS.md
├── src/  public/  prisma/    frontend source code
├── package.json              frontend dependencies and scripts
├── .env.local                frontend defaults (direct mode) — ready to use
└── mini-services/
    └── eptask-api/           the Python simulation service
        ├── main.py           FastAPI app
        ├── run.sh            start script (macOS/Linux)
        ├── requirements.txt  Python dependencies
        ├── app/              services: corridor, cell, outage, jobs, auth, osm
        ├── core/             ORIGINAL eptask notebook modules (do not edit)
        ├── assets/           demo bundle: graph, results, ONNX models
        │   └── osm_cache/    bundled OpenStreetMap extract for the corridor
        └── tests/            pytest suite (55 tests)
```

---

## 4. Install the backend

Open a terminal **in the `mini-services/eptask-api` folder**.

**macOS / Linux**

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

**Windows (PowerShell)**

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

The install downloads PyTorch (CPU), onnxruntime, FastAPI and friends —
allow 5–10 minutes on a normal connection.

> **Windows + PowerShell execution policy:** if activating the venv fails
> with "running scripts is disabled", run
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` once, then retry.

Start the service:

**macOS / Linux**

```bash
bash run.sh
```

**Windows (with the venv activated)**

```powershell
python -m uvicorn main:app --host 0.0.0.0 --port 8100
```

Wait for `Application startup complete.` and verify:

```
curl http://localhost:8100/health        →  {"status":"ok", ...}
```

You can also open http://localhost:8100/docs for the interactive API docs.

---

## 5. Install the frontend

Open a **second** terminal **in the project root** (the folder with
`package.json`).

```bash
npm install          # 2–4 minutes
npm run build        # production build (recommended)
npm run start        # serves the console on http://localhost:3000
```

or, for development with hot reload:

```bash
npm run dev
```

`.env.local` shipped with the zip already contains the correct laptop
settings (`NEXT_PUBLIC_API_URL=http://localhost:8100`). Do nothing else.

Now open **http://localhost:3000** in your browser. The header should show
**"simulation service online"** within a few seconds.

---

## 6. Take the tour (2 minutes)

1. **Overview** — what the app is, where every number comes from.
2. **Corridor · N1** — the 3D map. Press *Run simulation*: the ambulance,
   convoy and civilian traffic are simulated live by `corridor.run_trial`
   (the notebook's algorithm, not a replay). Use the **Road network source**
   card:
   - *Load real OSM roads* — uses the bundled extract (or fetches fresh with
     internet) and rebuilds the road graph; the 3D map redraws real roads
     and place-snapping distances are reported honestly.
   - *Notebook schematic* — back to the notebook's original two-route map.
3. **Compare networks** — pick a hazard preset or tune footprint/traffic,
   choose two warning-network modes, *Run side-by-side comparison*: two maps,
   informed-share curves, and a delta table (which network saved how many
   minutes).
4. **VEC cell** — the 558 m micro-scale cell driven by the shipped ONNX
   policies; try an outage event and the decision explanations.
5. **Outage study** — the paired C3 study, any k, any seeds, live.
6. **Reference** — recorded artifacts from the notebook run, clearly labeled
   as recordings.
7. **About** — architecture, fidelity evidence, honest limitations.

---

## 7. Configuration (all optional)

Environment variables, backend side (`mini-services/eptask-api`):

| Variable | Default | Effect |
|---|---|---|
| `EPTASK_PORT` | `8100` | HTTP port of the simulation service |
| `EPTASK_API_KEY` | *(unset)* | **set it to require an API key** on every `/api/*` call. Clients send `X-API-Key: <key>` (the console shows a key gate; image URLs use `?api_key=`) |
| `EPTASK_DB` | `<backend>/data/jobs.db` | SQLite file for persistent job history |
| `EPTASK_OSM_CACHE` | `<backend>/assets/osm_cache` | where Overpass extracts are cached |
| `EPTASK_LOG_LEVEL` | `INFO` | `DEBUG` for verbose logs |
| `EPTASK_CORE` / `EPTASK_ASSETS` | bundled `core/` / `assets/` | override module/asset locations |

Frontend side (`.env.local`, effective on the next `npm run build` / `dev`):

| Variable | Default | Effect |
|---|---|---|
| `NEXT_PUBLIC_API_URL` | `http://localhost:8100` | where the browser finds the API |
| `NEXT_PUBLIC_GATEWAY_MODE` | *(unset)* | leave unset on a laptop; sandbox deployments set `1` to route through a gateway |

A `.env.example` in the project root documents everything; copy it to
`.env.local` (frontend) or export the variables (backend) as needed.

### Enabling authentication (recommended if you share the machine)

```bash
# macOS/Linux
export EPTASK_API_KEY="a-long-random-string"
bash run.sh
```

```powershell
# Windows PowerShell
$env:EPTASK_API_KEY = "a-long-random-string"
python -m uvicorn main:app --host 0.0.0.0 --port 8100
```

Then in the console: reload the page, paste the same key into the gate, done.
`/health` stays open so you can check liveness without the key.

---

## 8. Offline behaviour

- **Simulations** run fully offline — models, graph and reference data ship
  with the app.
- **Real OSM roads**: a 17 MB extract of the corridor is bundled, so *Load
  real OSM roads* works offline too. *Re-fetch* (fresh Overpass data) needs
  internet; if all mirrors are unreachable the service keeps the current
  graph and reports the fetch error honestly. NASA COOLR landslide points
  stay the bundled sample (live COOLR needs an Earthdata login).

---

## 9. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Console header says *simulation service unreachable* | The backend is not running, or the frontend was built before `.env.local` existed. Start the backend, then rebuild (`npm run build`). |
| `pip install torch` is slow / fails | Use the CPU wheel: `pip install torch --index-url https://download.pytorch.org/whl/cpu`, then `pip install -r requirements.txt` again. |
| Port 8100 or 3000 already in use | Change the port: `EPTASK_PORT=8200 bash run.sh` and set `NEXT_PUBLIC_API_URL=http://localhost:8200` in `.env.local` (rebuild the frontend), or free the port. |
| Windows firewall prompt on first start | Allow access on private networks — uvicorn binds `0.0.0.0` for the sandbox convention; for a purely local machine you can use `--host 127.0.0.1`. |
| The 3D map is empty / grey | WebGL2 is required for the map. The panels stay usable without it; try Chrome/Edge/Firefox with hardware acceleration on. |
| OSM fetch reports mirror failures | Your network blocks the Overpass API. Use the bundled extract (it is used automatically when *Re-fetch* fails), or retry later. |
| First OSM load is slow (≈ 20–60 s) | Normal: the graph (≈ 160 k nodes) is built and analysed; the result is cached in memory. Simulations on OSM roads take ~3–8 s per trial (schematic: ~1 s). |
| History disappeared | v2 persists history in `mini-services/eptask-api/data/jobs.db`. If you deleted that file, history resets — everything else is unaffected. |
| Auth gate loops | The key in the browser must match `EPTASK_API_KEY` exactly. Clear it (Cancel) and re-enter, or unset the env var to disable auth. |

---

## 10. Running the test suite (optional but recommended)

```bash
cd mini-services/eptask-api
python -m pytest tests/ -q          # 55 tests, ~3 minutes
```

Covers: asset integrity, health/meta/graph, deterministic reproduction of
the notebook's recorded traces (byte-identical), validation errors, auth,
persistence across restart, side-by-side compare, OSM ingestion and offline
fallback.

---

## 11. Performance expectations (measured on 4 vCPU)

| Operation | Typical wall time |
|---|---|
| Backend startup (asset load) | 1–2 s |
| Corridor run, schematic, no convoy | ~1–2 s |
| Corridor run, schematic, with convoy (7 trials) | ~8–14 s |
| Corridor run on OSM roads, with convoy | ~40–70 s |
| Side-by-side comparison (2 runs, no convoy) | ~4–8 s |
| VEC cell 520 ticks | ~1–2 s |
| Paired outage study (2 policies × 3 k × 3 seeds) | ~6–10 s |
| OSM graph rebuild from bundled cache | ~15–30 s |
| OSM graph rebuild with fresh fetch | + 10–60 s network time |

Two simulations may run concurrently; further requests queue and the UI
shows live progress reported by the simulation itself.

---

## 12. Stopping

`Ctrl+C` in each terminal. The SQLite history, OSM cache and logs survive.

Enjoy the console — and if a run contradicts your intuition, that is the
research console doing its job: every number is computed live from the
notebook's own code, on the road network you chose.
