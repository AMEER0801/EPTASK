# RUN REPORT — EPtask V7.2 real-data notebook (R = 1000, user-directed run)

## 1. Verdict

**COMPLETED WITH ONE FAILED SELF-CHECK (7/8 checks passed).** The notebook ran through its final cell; 7 of 8 self-checks passed. The 8th — `N2 reproduces the tested copy (2 ambulances, 20 incidents, unlimited)` — failed because at R = 1000 the golden-hour gain is **+3.69 pp**, while the tested copy's value (from the author's R = 400 reference) is 4.44 with tolerance 0.01. The final `assert all(...)` therefore raised, so the nbconvert command as specified (no `--allow-errors`) exited 1 and wrote no executed notebook; the result files had already been written before the assert. A second, otherwise identical execution with `--allow-errors` (same seed 7, same notebook, nothing edited) was used to capture the executed notebook with the failure recorded inside it. Both runs' outputs are byte-identical except the `runtime_s` timing field. Per the user's instruction ("run 1000 and deliver the asked files with also previous executed files"), everything is delivered below. **No threshold, code, or data was changed at any point, and nothing was fetched from the internet.**

## 2. Integrity context (why R = 1000)

- First attempt stopped at Step 2: `EPtask_V7_2_realdata.ipynb: FAILED` in `sha256sum -c SHA256SUMS` (21/22 files OK; manifest `59fe8306…` vs actual `6bd60804…`). Root cause previously reported: the shipped notebook was changed to R = 1000 scenarios after the manifest was written (its own generator, README and reference all still say R = 400).
- The user then directed: run 1000 and deliver. The run therefore used the shipped notebook exactly as-is.

## 3. Environment

Python 3.12.14 (venv) · numpy 2.1.3 · networkx 3.6.1 · matplotlib 3.9.2 · nbconvert 7.17.1 · nbformat 5.10.4 · pytest 9.0.2 · 2 vCPU, no GPU · no internet access used at any point.

## 4. Steps and results

| Step | Command / action | Result |
|---|---|---|
| 2 | `sha256sum -c SHA256SUMS` | 21/22 OK; `EPtask_V7_2_realdata.ipynb: FAILED` (reported; user directed to proceed with the shipped R = 1000 notebook) |
| 3 | version recording | see environment above |
| 4 | `python -m pytest -q tests` | **6 passed, 14 warnings in 2.62 s** (exit 0; warnings are matplotlib/pyparsing deprecation notices, pre-existing and unrelated to the tested code) |
| 5 (run 1) | exact command from the instructions (foreground, `tee run.log`) | 2026-10-08 19:13:03 → 19:14:29 UTC, **86 s wall** (notebook internal timer 78 s); nbconvert **exit 1** — final cell raised `AssertionError`; `results_v72/results_v72.json`, `n1_syaphrubesi_access.png`, `n2_golden_hour.png` were written before the assert |
| 5b (run 2, artifact capture) | same command + `--allow-errors` (`tee run_allowerrors.log`) | 19:16:00 → 19:17:27 UTC, **87 s wall** (internal 79 s); exit 0; executed notebook written: 13/13 cells executed, last cell records the 7/8 stdout **and** the AssertionError |
| 6 | last-cell check | **7/8 checks passed — NOT 8/8**; verbatim output in section 5 |
| 7 | comparison vs `reference/results_v72/results_v72.json` (R = 400) | see section 6 |
| — | wall time | run 1: 86 s; run 2: 87 s; pytest 2.6 s |

**Determinism between run 1 and run 2** (no re-run cherry-picking): both figures byte-identical (`44bed50e…`, `7a2379b3…`); `results_v72.json` identical except one line — `"runtime_s": 77.6` (run 1) vs `"runtime_s": 78.9` (run 2). No scientific value differs.

## 5. Failing cell — full output (verbatim)

```
PASS every Copernicus layer read (433 buildings, 5 bridges)
PASS damage reaches the graph (4.63 km, 5 bridge edges)
PASS N1 informed is never slower than uninformed
PASS N1 informed stopping point is outside the hazard extent
PASS N2 capacity: unlimited reaches people no later than cap 4
PASS same graph as the tested copy
PASS same matched damage as the tested copy
FAIL N2 reproduces the tested copy (2 ambulances, 20 incidents, unlimited) (+3.69 pp)

7/8 checks passed | results: results_v72/results_v72.json | 78 s
```

Followed by the cell error:

```
AssertionError: a self-check failed: send the whole output back
```

(The full traceback including the complete cell source is preserved in `run.log`; the executed notebook's last cell contains the same output and the `AssertionError`. `run_allowerrors.log` holds only nbconvert's console messages — with `--allow-errors` the cell outputs, including the error, are recorded inside the notebook instead.)

## 6. Comparison with the reference (step 7)

Reference = author's run at R = 400 (seed 7, FULL). This run = R = 1000 (seed 7, FULL).

**Identical (deterministic):**
- graph: 109,890 nodes / 110,389 edges / 105 July national-highway ways — identical
- matched destroyed km: 4.634135 — identical (exact value 4.634134689157941 both sides)
- matched possibly-damaged km: 0.843758 — identical (exact value 0.8437582703393659 both sides)
- every N1 access row: all 6 rows × all 15 fields identical (informed = uninformed travel time, difference 0.0 min in all rows; victim-reach times 58.75–132.00 min; informed stopping points outside the hazard extent in all rows)

**Different (stochastic, expected from R = 1000 vs R = 400):**
- every N2 row — all 9 regimes differ in the golden-hour share and the three survivor percentages (rule_mean / base_mean / diff / rel_pct / ci95 for golden, surv30, surv60, surv120). This is the direct consequence of the scenario count: R = 1000 draws a different (larger) sample than the R = 400 reference, with 95% CIs ≈ 0.63× narrower (√(400/1000)). Signs and magnitudes remain consistent, e.g.:
  - headline regime "2 ambulances, 20 incidents, cap 4": golden diff ref +1.40 pp → mine +1.27 pp; survivors ref +5.5 / +10.5 / +14.1 % → mine +4.6 / +9.7 / +13.6 % (half-life 30/60/120)
  - the check-failing regime "2 ambulances, 20 incidents, unlimited": golden diff ref +4.44 pp → mine +3.69 pp (this is exactly the value the failed self-check tests)
- The full field-by-field listing (every field of every N1 and N2 row) is in `reference_comparison.txt`.

## 7. Warnings and errors (verbatim list)

1. `sha256sum: WARNING: 1 computed checksum did NOT match` — `EPtask_V7_2_realdata.ipynb: FAILED` (Step 2, first attempt; user then directed to run the shipped R = 1000 notebook)
2. `FAIL N2 reproduces the tested copy (2 ambulances, 20 incidents, unlimited) (+3.69 pp)`
3. `AssertionError: a self-check failed: send the whole output back` (final cell, run 1; nbconvert exit 1)
4. pytest: 14 warnings (matplotlib `_fontconfig_pattern`/`_mathtext` pyparsing deprecations — environment-level, unrelated to the package code)
5. `results_v72.json` differs between runs 1 and 2 only in `"runtime_s"` (77.6 vs 78.9 — timing field)

## 8. Deliverable

`EPtask_V7_2_realdata_RUN_<timestamp>.zip` containing:

- `EPtask_V7_2_realdata_EXECUTED.ipynb` — the executed notebook (13/13 cells; last cell carries the 7/8 output and the AssertionError)
- `results_v72/` — `results_v72.json`, `n1_syaphrubesi_access.png`, `n2_golden_hour.png` (from run 2; byte-identical to run 1 except `runtime_s`)
- `run.log` — run 1, the exact command from the instructions (exit 1 at the assert)
- `run_allowerrors.log` — run 2, the `--allow-errors` artifact-capture run (exit 0)
- `reference_comparison.txt` — full step-7 comparison
- `RUN_REPORT.md` — this report
- `previous_executed/` — the previously executed/delivered files:
  - `EPtask_V7_1_FULL_20261008-124455-ba2667.zip` — the V7.1 FULL run of record (the run the V7.2 notebook itself references as `v71_run_of_record`), as delivered previously
  - `EPtask_V7_2_realdata_RUN_20261008-190658_FAILED_AT_STEP2_CHECKSUM.zip` — the previous attempt's evidence package (checksum-failure report)
  - `PREVIOUS_FILES_README.md` — what these are
- `SHA256SUMS` — checksums of all returned files

The zip's own sha256 is provided in the sidecar file `EPtask_V7_2_realdata_RUN_<timestamp>.zip.sha256` next to the zip.
