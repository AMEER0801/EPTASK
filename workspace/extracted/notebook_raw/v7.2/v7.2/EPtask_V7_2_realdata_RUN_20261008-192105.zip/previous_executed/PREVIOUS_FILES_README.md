# Previously executed / delivered files (included per user request)

1. `EPtask_V7_1_FULL_20261008-124455-ba2667.zip`
   The EPtask V7.1 FULL run of record (executed notebook, results/, eptask/, logs, RUN_REPORT.md,
   pip_freeze.txt, environment.txt). This is the run the V7.2 notebook itself references as
   `v71_run_of_record = 20261008-124455-ba2667`. sha256:
   70d42c035bfb07287230e8ca78ae7ab881dbbae6bf6e14e185a7f62ffc6aa394

2. `EPtask_V7_2_realdata_RUN_20261008-190658_FAILED_AT_STEP2_CHECKSUM.zip`
   The previous V7.2 attempt's evidence package: that run stopped at Step 2 because
   `EPtask_V7_2_realdata.ipynb` did not match SHA256SUMS (21/22 files OK). Nothing was executed
   in that attempt. sha256:
   d5519e7e74cd2052ef736a226fbb94219023586ebfd5fdfa948f88494a8cc92b
