# RUN REPORT — EPtask V7.2 real-data notebook

## Verdict

**FAILED AT STEP 2 (sha256sum -c SHA256SUMS).** The notebook `EPtask_V7_2_realdata.ipynb` does not match the checksum recorded in `SHA256SUMS`. Per the run instructions ("If not, stop and report which files fail"), execution stopped at this gate: the notebook was **never executed**, pytest was **not run** (it is available, pytest 9.0.2), and steps 5–8 (execute, 8/8 checks, reference comparison, standard deliverable zip) were **not performed**.

## Step 2 result: 21 of 22 files OK, 1 FAILED

```
EPtask_V7_2_realdata.ipynb: FAILED      <-- the only failure
PROMPT_agent_V72.md: OK
README_V72.md: OK
data/ATTRIBUTION.md: OK
data/EMSR927_AOI01_GRA_PRODUCT_v1.gpkg: OK
data/incidents-1791480126992.csv: OK
data/osgeonepal_npl_hospitals_osm_gpkg.zip: OK
data/osgeonepal_npl_hospitals_osm_metadata.json: OK
data/osm_nh_extra.json: OK
data/osm_nh_extra_prov.json: OK
data/osm_roads.json: OK
data/osm_roads_prov.json: OK
eptask/corridor.py: OK
eptask/datasets.py: OK
eptask/dispatch.py: OK
eptask/realdata.py: OK
eptask/runlog.py: OK
reference/results_v72/n1_syaphrubesi_access.png: OK
reference/results_v72/n2_golden_hour.png: OK
reference/results_v72/results_v72.json: OK
tests/test_v72.py: OK
tools/make_notebook.py: OK
```

Failed file detail:

| | sha256 |
|---|---|
| Expected (SHA256SUMS manifest) | `59fe83066750ab41555fea71fd81bc4f2e259bbf11e7c7c398238fafe41f9474` |
| Actual (file in the zip, 17,196 bytes) | `6bd6080447c1946d256964196b2d914164536a195b0ce37c7508f9aaafc4df92` |

The actual hash was confirmed three independent ways (two separate `unzip` extractions to different directories, plus a direct in-memory read of the zip entry via Python `zipfile`), all agreeing on `6bd60804…`. The zip archive itself is not corrupted; its content genuinely differs from the manifest.

## Root-cause evidence (read-only diagnostics, nothing was modified)

1. **Timestamps inside the zip**: `SHA256SUMS` (and every other file) has mtime `2026-10-08 18:47`; `EPtask_V7_2_realdata.ipynb` has mtime `2026-10-08 18:50` — the notebook was changed ~3 minutes *after* the manifest was written, without updating `SHA256SUMS`.

2. **Semantic diff vs the package's own generator**: `tools/make_notebook.py` (which itself verifies OK) was run offline in an isolated copy of the tree (no network, no edits to the original working files; all `data/` inputs verified OK, and the generator embeds their hashes, so the input is identical). The notebook it produces differs from the shipped notebook in exactly two lines, in two cells (all other 11 cells and the metadata are identical):

   - Cell 1 (parameters):
     - generator: `RUN_MODE = "FULL"     # FULL: 400 scenarios per cell ...`
     - shipped:   `RUN_MODE = "FULL"     # FULL: 1000 scenarios per cell ...`
   - Cell 2:
     - generator: `T0 = time.time(); R = 400 if RUN_MODE == "FULL" else 60`
     - shipped:   `T0 = time.time(); R = 1000 if RUN_MODE == "FULL" else 60`

   That is, the shipped notebook was changed to run **R = 1000 scenarios per cell** in FULL mode, while the shipped generator, the README and the reference run all use **R = 400**.

3. **Reference run parameters**: `reference/results_v72/results_v72.json` (verifies OK) records `run_mode = FULL, R = 400, seed = 7, 8/8 checks passed, runtime 72.8 s`. A run of the shipped notebook at R = 1000 would take materially longer than the "1–2 minutes" stated in the instructions and its results would not be comparable to the reference in step 7.

Note: regenerating the notebook in this environment yields a third hash (`6e7b6712…`) rather than the manifest's `59fe8306…`; byte-level reproduction depends on the authoring environment's nbformat/Python serialization (here nbformat 5.10.4 / Python 3.12.14). The R=400 vs R=1000 semantic difference above is therefore the meaningful, environment-independent finding.

## Environment (recorded for context; steps 3–8 were not executed)

- Python 3.12.14; numpy 2.1.3; networkx 3.6.1; matplotlib 3.9.2; nbconvert 7.17.1; nbformat 5.10.4; pytest 9.0.2 (available, not run); 2 vCPU.
- No internet was used at any point. Nothing in the working tree was edited, renamed, or re-run.

## What would be needed to proceed

Not attempted, per the stop rule. To unblock, the package author would need to either (a) restore the R = 400 notebook whose hash is `59fe8306…` and keep `tools/make_notebook.py` as is, or (b) update both the generator and `SHA256SUMS` (and the README / reference expectations) to the intended R. The shipped notebook's R = 1000 setting contradicts the README, the generator, and the reference results, so the intended value cannot be inferred from the package alone.
