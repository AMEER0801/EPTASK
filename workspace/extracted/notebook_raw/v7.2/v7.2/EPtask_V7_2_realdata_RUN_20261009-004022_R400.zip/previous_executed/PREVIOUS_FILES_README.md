# Previously executed / delivered files (kept for the record)

1. EPtask_V7_1_FULL_20261008-124455-ba2667.zip
   EPtask V7.1 FULL run of record (the run the V7.2 notebook references as v71_run_of_record).
   sha256 70d42c035bfb07287230e8ca78ae7ab881dbbae6bf6e14e185a7f62ffc6aa394
2. EPtask_V7_2_realdata_RUN_20261008-190658_FAILED_AT_STEP2_CHECKSUM.zip
   First V7.2 attempt: stopped at Step 2 (notebook checksum mismatch). Nothing executed.
   sha256 d5519e7e74cd2052ef736a226fbb94219023586ebfd5fdfa948f88494a8cc92b
3. EPtask_V7_2_realdata_RUN_20261008-192105.zip
   Second V7.2 attempt: the R=1000 run (user-directed). 7/8 checks; N2 differs from the
   R=400 reference as expected for a different scenario count. Best used with the R=400
   run in this package, which matches the reference exactly.
   sha256 a2a8b8eac0ef832d2184ba6339eac336c6d963fef674a785a92b197b6bab6ce9
