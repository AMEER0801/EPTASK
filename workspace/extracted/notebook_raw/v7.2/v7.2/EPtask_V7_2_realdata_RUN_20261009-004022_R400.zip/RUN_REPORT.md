# RUN REPORT — EPtask V7.2 real-data notebook (R = 400, reference-matching run)

## 1. Verdict

**COMPLETE — 8/8 checks passed; every outcome matches the reference.** After the user directed "try to match the output… if R=1000 doesn't match, choose the best one to match outcomes", the R=1000 run (previously delivered, 7/8 checks, all N2 rows differing from the reference) was compared against a run of the package's intended **R = 400** notebook. The R=400 run reproduces the author's reference **exactly**: 0 differences in every step-7 field, a full recursive JSON diff of 1 field (`runtime_s` only), and pixel-identical figures. Match score (mean |Δ| over all 144 N2 numeric fields): **R=400 = 0.000000 pp** vs R=1000 = 0.588702 pp → **R=400 is the best match and is the run delivered as primary**. No code or data was edited; nothing was fetched from the internet.

## 2. How the R=400 notebook was obtained (transparency)

- The shipped `EPtask_V7_2_realdata.ipynb` in the zip is the R=1000 variant and does not match the package's own SHA256SUMS manifest (reported previously).
- The package's own generator `tools/make_notebook.py` (sha256-verified OK in the manifest; still hard-coded to R=400) was run offline to regenerate the intended notebook: `RUN_MODE="FULL"`, `R = 400`, `SEED = 7` — the exact configuration the README, the generator and the reference all describe.
- The generator assigns **random notebook cell IDs** (nbformat behaviour), so its byte hash differs on every generation (three regenerations observed: `1a07aac4…`, `6806e2a2…`, `facec2d4…` — all cell-source-identical). The manifest's `59fe8306…` is therefore not byte-reproducible by anyone, including its author; cell IDs do not affect execution. Semantic content of the regenerated notebook = the manifest's intended R=400 notebook.
- Data integrity at run time: the notebook re-verifies all five data files against the hashes embedded at generation — all printed "same as tested copy" (`SAME_DATA = True`).

## 3. Environment

Python 3.12.14 · numpy 2.1.3 · networkx 3.6.1 · matplotlib 3.9.2 · nbconvert 7.17.1 · nbformat 5.10.4 · pytest 9.0.2 · 2 vCPU, no GPU · no internet used. (The reference was produced with matplotlib 3.10.8 — see §6.)

## 4. Steps and results

| Step | Command / action | Result |
|---|---|---|
| 2 | `sha256sum -c SHA256SUMS` (original tree) | 21/22 OK; shipped notebook FAILED (it is the R=1000 variant) — reported previously; user directed to attain matching outcomes |
| 3 | environment | see §3 |
| 4 | `python -m pytest -q tests` (in the run tree) | **6 passed**, 14 warnings, 2.72 s, exit 0 (`pytest_output.txt`) |
| 5 | `jupyter nbconvert --to notebook --execute EPtask_V7_2_realdata.ipynb --output EPtask_V7_2_realdata_EXECUTED.ipynb --ExecutePreprocessor.timeout=1800` (regenerated R=400 notebook, foreground, `tee run.log`) | 2026-10-09 00:36:48 → 00:37:37 UTC, **49 s wall** (notebook-internal timer 41 s); **exit 0**; executed notebook written, 13/13 cells executed, zero error outputs |
| 6 | last-cell check | **8/8 checks passed** — verbatim output in §5 |
| 7 | comparison with `reference/results_v72/results_v72.json` | **identical** — see §6 |
| 8 | delivery | `EPtask_V7_2_realdata_RUN_<ts>_R400.zip` + `DOWNLOAD_DASHBOARD.html` at the download root |

## 5. Last cell — full output (verbatim)

```
PASS every Copernicus layer read (433 buildings, 5 bridges)
PASS damage reaches the graph (4.63 km, 5 bridge edges)
PASS N1 informed is never slower than uninformed
PASS N1 informed stopping point is outside the hazard extent
PASS N2 capacity: unlimited reaches people no later than cap 4
PASS same graph as the tested copy
PASS same matched damage as the tested copy
PASS N2 reproduces the tested copy (2 ambulances, 20 incidents, unlimited) (+4.44 pp)

8/8 checks passed | results: results_v72/results_v72.json | 41 s
```

## 6. Comparison with the reference (step 7) — verdict: IDENTICAL

Step-7 fields (graph nodes/edges, matched destroyed km, every N1 access row × every field, every N2 row × golden-hour share and the three survivor percentages, with means/diffs/CIs): **274/274 entries identical, 0 different** (`reference_comparison_R400_full.txt`).

Full recursive JSON diff (every field in the file, not just step-7): **1 differing field** — `/runtime_s: ref 72.8 vs run 40.7` (pure timing; this machine is faster). All scientific values are bit-identical.

Figures: both PNGs have **byte-identical pixel data (IDAT)** to the reference; the only difference is the `tEXt` metadata chunk, which carries the matplotlib version string (mine 3.9.2 vs the author's 3.10.8 — hence the 1-byte size difference). No visual or numeric difference.

Headline numbers (all identical to the reference): N2, 2 ambulances / 20 incidents / cap 4: golden-hour share 7.05 % → 8.45 % (+1.40 ± 0.26 pp); modelled survivors +5.5 % / +10.5 % / +14.1 % (half-life 30/60/120). Unlimited-capacity pilot regime: +4.44 ± 1.08 pp (the value the previously failing check tests).

## 7. Warnings (verbatim list)

1. `EPtask_V7_2_realdata.ipynb: FAILED` in `sha256sum -c SHA256SUMS` (shipped notebook is the R=1000 variant, changed after the manifest was written) — reason this R=400 run uses the package generator's output, per user direction.
2. The regenerated notebook's byte hash cannot equal the manifest's `59fe8306…` (random cell IDs; see §2). Three regenerations produced three hashes with identical cell sources.
3. `runtime_s` differs from the reference (40.7 vs 72.8) — machine speed only.
4. PNG `tEXt` metadata differs (matplotlib 3.9.2 vs 3.10.8); pixel data identical.
5. pytest: 14 warnings (matplotlib/pyparsing deprecations — environment-level, unrelated to the package code).
6. R=1000 run (previous delivery): 7/8 checks, `AssertionError: a self-check failed: send the whole output back`, N2 check value +3.69 pp — retained and delivered in `previous_executed/` for the record.

## 8. Wall time and devices

49 s total for the executed notebook (nbconvert, foreground, 2 vCPU CPU-only); pytest 2.72 s; comparison and packaging minutes.
